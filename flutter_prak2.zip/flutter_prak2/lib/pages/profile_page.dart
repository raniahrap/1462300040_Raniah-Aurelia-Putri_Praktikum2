import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _buildHeader(),
          const SizedBox(height: 60),
          Expanded(
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _buildInfoRow(Icons.person_outline, 'Raniah Aurelia Putri'),
                _buildInfoRow(Icons.phone_outlined, '1462300040'),
                _buildInfoRow(Icons.email_outlined, 'aureliaputri08@gmail.com'),
                _buildInfoRow(Icons.location_on_outlined, 'Surabaya'),
                _buildInfoRow(Icons.camera_alt_outlined, 'raniahrap_'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Main blue header background
        Container(
          height: 180,
          width: double.infinity,
          color: const Color(0xFFBBDEFB),
          child: const SafeArea(
            child: Padding(
              padding: EdgeInsets.only(top: 12),
              child: Text(
                'Profile',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: Colors.black87,
                ),
              ),
            ),
          ),
        ),
        // Avatar circle
        Positioned(
          bottom: -50,
          left: 0,
          right: 0,
          child: Center(
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
                border: Border.all(color: Colors.white, width: 3),
              ),
              child: const CircleAvatar(
                radius: 47,
                backgroundColor: Color(0xFFBBDEFB),
                child: Icon(
                  Icons.person,
                  size: 55,
                  color: Color(0xFF64B5F6),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Container(
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFFE0E0E0), width: 1),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF42A5F5), size: 22),
          const SizedBox(width: 16),
          Text(
            text,
            style: const TextStyle(fontSize: 15, color: Colors.black87),
          ),
        ],
      ),
    );
  }
}
